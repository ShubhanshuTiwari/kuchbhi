package com.capgemini.Bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.IAdminRepo;
import com.capgemini.Bookstore.bean.Admin;
@Service
public class AdminService implements IAdminservice {

	@Autowired
	IAdminRepo adminrepo;
	@Override
	public Admin showAdmin() {
		// TODO Auto-generated method stub
		return adminrepo.showAdmin();
	}

}
