package com.capgemini.Bookstore.Repository;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Admin;
@Repository
public class AdminRepo implements IAdminRepo {

	@Override
	public Admin showAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

}
