package com.capgemini.Bookstore.service;

import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.bean.Admin;

@Service
public interface IAdminservice {

	public Admin showAdmin();
}
