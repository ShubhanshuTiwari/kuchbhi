package com.capgemini.Bookstore.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Bookstore.bean.Admin;
@Repository
@Transactional
public class LoginRepo implements IloginRepo {

	
	@PersistenceContext
	EntityManager entitymanager;
	public void signUp(Admin admin) {
		// TODO Auto-generated method stub
		
		entitymanager.persist(admin);
		
	}

}
