package com.capgemini.Bookstore.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.service.ILoginService;

@RestController
public class LoginController {
	
	@Autowired
	ILoginService loginservice;
	
	@RequestMapping(method = RequestMethod.GET, value = "/hello")
	public String Hello() {
		return "Hello";
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/adminsignup")
	public void signUp(@RequestBody Admin admin) {
		
		 loginservice.signUp(admin);	
	}
	
}
