package com.capgemini.Bookstore.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.IloginRepo;
import com.capgemini.Bookstore.bean.Admin;
@Service
public class LoginService implements ILoginService {

	@Autowired
	IloginRepo loginrepo;
	
	@Override
	public void signUp(Admin admin) {
		// TODO Auto-generated method stub
		 loginrepo.signUp(admin);
	}

}
