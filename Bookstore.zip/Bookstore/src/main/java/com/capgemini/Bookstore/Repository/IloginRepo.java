package com.capgemini.Bookstore.Repository;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Bookstore.bean.Admin;
@Repository
@Transactional
public interface IloginRepo {

	public void signUp(Admin admin);
}
