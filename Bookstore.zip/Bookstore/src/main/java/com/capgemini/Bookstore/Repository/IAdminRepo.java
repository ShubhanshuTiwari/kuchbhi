package com.capgemini.Bookstore.Repository;

import com.capgemini.Bookstore.bean.Admin;

public interface IAdminRepo {

	public Admin showAdmin();
}
