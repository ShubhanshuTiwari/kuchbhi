package com.capgemini.Bookstore.service;

import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.bean.Admin;
@Service
public interface ILoginService {

	public void signUp(Admin admin);
}
