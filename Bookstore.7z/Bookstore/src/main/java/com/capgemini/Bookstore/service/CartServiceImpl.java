package com.capgemini.Bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.AdminRepo;
import com.capgemini.Bookstore.Repository.CartRepo;
import com.capgemini.Bookstore.bean.Cart;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartRepo cartrp;
	 
	@Override
	public Cart removeCart() {
		
		return cartrp.removeCart();
	}

	@Override
	public Cart addBookToCart() {
		
		return cartrp.addBookToCart();
	}

	@Override
	public Cart updateQuantity() {
		
		return cartrp.updateQuantity();
	}

}
