package com.capgemini.Bookstore.Repository;

import static org.mockito.Mockito.CALLS_REAL_METHODS;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;
import com.capgemini.Bookstore.bean.Category;
import com.capgemini.Bookstore.bean.Customer;
import com.capgemini.Bookstore.bean.Order;


@Repository

@Transactional
public class AdminRepoImpl  implements AdminRepo {

	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public List<Customer> viewAllCustomer() {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query = entityManager.createQuery("select cust from Customer cust ", Customer.class); 
		List<Customer> list = query.getResultList();
		System.out.println("Customer data"+list);
		return list;
	}

	@Override
	public Admin addAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Admin deleteAdmin(int id) {
		// TODO Auto-generated method stub
		
		
		Admin adm= entityManager.find(Admin.class, id);
		entityManager.remove(adm);
		entityManager.flush();
		return adm;
		
	}
	@Override
	public Admin updateAdmin(String adminEmailId,Admin admin) {
		adminEmailId=adminEmailId+".com";
		System.out.println("Id:::"+adminEmailId);
		Query query = entityManager.createQuery("Select adminId from Admin adm where adm.adminEmailId=:adminEmailId"); 
		query.setParameter("adminEmailId", adminEmailId);
		System.out.println("hi i am update query::"+query);
		int id =  (int) query.getSingleResult();
		System.out.println("Check");
		admin.setAdminId(id);
		entityManager.merge(admin);
		entityManager.flush();
		
	/*	System.out.println(admin);
	
		Query query=entityManager.createQuery("Select adm from Admin adm where adm.adminEmailId=:ids");
		query.setParameter("ids",adminEmailId);
		
		System.out.println("hello \n");
		
		List<Admin> list= new ArrayList<Admin>();
		list =  query.getResultList();
		
		System.out.println(list);*/
		
		return admin;
	}

	@Override
	public List<Category> viewAllCategories() {
		// TODO Auto-generated method stub
		TypedQuery<Category> query = entityManager.createQuery("select cat from Category cat ", Category.class); 
		List<Category> list = query.getResultList();
		System.out.println("category data"+list);
		return list;
	}

	@Override
	public Category createCategory( Category category) {
		// TODO Auto-generated method stub
		entityManager.persist(category);
		return category;
	}

	@Override
	public List<Category> deleteCategories(int categoryId) {
		// TODO Auto-generated method stub
		List<Category> list= (List<Category>) entityManager.find(Category.class, categoryId);
		entityManager.remove(list);
		entityManager.flush();
		return list;
	}

	@Override
	public Category updateCategories(int categoryId,Category category) {
		// TODO Auto-generated method stub
		System.out.println("Id:::"+categoryId);
		Query query = entityManager.createQuery("Select categoryId from Category cat where cat.categoryId=:categoryId"); 
		query.setParameter("categoryId", categoryId);
		System.out.println("hi i am update query::"+query);
		int id =  (int) query.getSingleResult();
		System.out.println("Check");
		category.setCategoryId(id);
		entityManager.merge(category);
		entityManager.flush();
		return category;
	}

	@Override
	public List<Book> viewAllBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> deleteBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book addBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book updateBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer createCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> deleteCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer updateCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BookReview> viewAllReviews() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BookReview> deleteReview() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookReview updateReview() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> viewAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order updateOrder() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order deleteOrder() {
		// TODO Auto-generated method stub
		return null;
	}

}
