package com.capgemini.Bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.Bookstore.Repository.LoginRepo;
import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Customer;

@Service
public class LoginServiceImpl implements LoginService {

	
	@Autowired
	LoginRepo loginrp;

	@Override
	public boolean addAdmin(Admin admin) {
		System.out.println("Hello1::"+admin);
		return loginrp.addAdmin( admin) ;
	}

	@Override
	public boolean addCustomer(Customer customer) {
		
		return loginrp.addCustomer(customer);
	}

	@Override
	public boolean loginAdmin(String adminEmailId, String password) {
		// TODO Auto-generated method stub
		return loginrp.loginAdmin(adminEmailId, password);
	}

	@Override
	public boolean loginCustomer(String customerEmail, String password) {
		// TODO Auto-generated method stub
		return loginrp.loginCustomer(customerEmail, password);
	}
	
}
