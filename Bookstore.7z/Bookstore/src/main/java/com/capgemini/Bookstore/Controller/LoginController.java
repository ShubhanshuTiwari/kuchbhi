package com.capgemini.Bookstore.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Customer;
import com.capgemini.Bookstore.service.LoginService;

@RestController
public class LoginController {

	@Autowired
	LoginService loginservice;
	
	@RequestMapping(method = RequestMethod.GET, value = "/hello")
	public String Hello() {
		return "Hello";
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/adminsignup")
	public void adminSignUp(@RequestBody Admin admin) {
		System.out.println("Hello:::::"+admin);
		 loginservice.addAdmin(admin);	
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/customersignup")
	public void customerSignUp(@RequestBody Customer customer) {
		System.out.println("Hello:::::"+customer);
		 loginservice.addCustomer(customer);	
	}
	@RequestMapping(method = RequestMethod.POST, value = "/adminsignin/{adminEmailId}/{password}")
	public boolean adminSignIn(@PathVariable("adminEmailId")String email,@PathVariable("password")String pass) {
		//System.out.println("Hello:::::"+email+" "+pass);
		 return loginservice.loginAdmin(email, pass);	
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/customersignin/{customerEmail}/{password}")
	public boolean customerSignIn(@PathVariable("customerEmail")String email,@PathVariable("password")String pass) {
		System.out.println("Hello:::::"+email+" "+pass);
		 return loginservice.loginCustomer(email, pass);	
	}
	
}
