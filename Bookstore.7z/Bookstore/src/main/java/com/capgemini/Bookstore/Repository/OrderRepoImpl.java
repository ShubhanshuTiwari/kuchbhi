package com.capgemini.Bookstore.Repository;
import org.springframework.stereotype.Repository;
import com.capgemini.Bookstore.bean.Order;
@Repository
public class OrderRepoImpl implements OrderRepo{

	@Override
	public Order viewAllDetailedOrder() {
		// TODO Auto-generated method stub
		return null;
	}

}
