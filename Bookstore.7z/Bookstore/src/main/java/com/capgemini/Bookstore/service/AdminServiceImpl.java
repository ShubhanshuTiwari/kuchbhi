package com.capgemini.Bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.AdminRepo;
import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;
import com.capgemini.Bookstore.bean.Category;
import com.capgemini.Bookstore.bean.Customer;
import com.capgemini.Bookstore.bean.Order;

@Service
public class AdminServiceImpl implements AdminService{

	
	@Autowired
	AdminRepo adminrp;
	
	
	@Override
	public List<Customer> viewAllCustomer() {
		
		return adminrp.viewAllCustomer();
	}

	@Override
	public Admin addAdmin() {
		
		return adminrp.addAdmin();
	}

	@Override
	public Admin deleteAdmin(int id) {
		
		return adminrp.deleteAdmin( id);
	}

	@Override
	public Admin updateAdmin(String adminEmailId,Admin admin) {
		// TODO Auto-generated method stub
		return adminrp.updateAdmin(adminEmailId,admin);
	}
	
	
	


	@Override
	public List<Category> viewAllCategories() {
		
		return adminrp.viewAllCategories();
	}

	@Override
	public Category createCategory( Category category) {
		
		return adminrp.createCategory(category);
	}

	@Override
	public Category deleteCategories(int categoryId) {
		
		return adminrp.deleteCategories( categoryId);
	}

	@Override
	public Category updateCategories(int categoryId,Category category) {
		
		return adminrp.updateCategories(categoryId,category);
	}

	@Override
	public List<Book> viewAllBook() {
		
		return adminrp.viewAllBook();
	}

	@Override
	public Book deleteBook(int id) {
		
		return adminrp.deleteBook(id);
	}

	@Override
	public Book addBook(Book book) {
		
		return adminrp.addBook(book);
	}

	@Override
	public Book updateBook() {
		
		return adminrp.updateBook();
	}

	@Override
	public Customer createCustomer() {
		
		return adminrp.createCustomer();
	}

	@Override
	public List<Customer> deleteCustomer() {
		
		return adminrp.deleteCustomer();
	}

	@Override
	public Customer updateCustomer() {
		
		return adminrp.updateCustomer();
	}

	@Override
	public List<BookReview> viewAllReviews() {
		
		return adminrp.viewAllReviews();
	}

	@Override
	public List<BookReview> deleteReview() {
		
		return adminrp.deleteReview();
	}

	@Override
	public BookReview updateReview() {
		
		return adminrp.updateReview();
	}

	@Override
	public List<Order> viewAllOrders() {
		
		return adminrp.viewAllOrders();
	}

	@Override
	public Order updateOrder() {
		
		return adminrp.updateOrder();
	}

	@Override
	public Order deleteOrder() {
		
		return adminrp.deleteOrder();
	}

	

}
