package com.capgemini.Bookstore.Repository;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Customer;
@Repository
public class CustomerRepoImpl implements CustomerRepo {

	@Override
	public Customer viewProfileDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer updateProfileDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
