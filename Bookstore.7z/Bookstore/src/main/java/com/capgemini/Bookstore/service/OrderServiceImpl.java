package com.capgemini.Bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.Bookstore.Repository.BookRepo;
import com.capgemini.Bookstore.Repository.OrderRepo;
import com.capgemini.Bookstore.bean.Order;

public class OrderServiceImpl implements OrderService{

	@Autowired
	OrderRepo orderrp; 
	@Override
	public Order viewAllDetailedOrder() {
		
		return orderrp.viewAllDetailedOrder();
	}

}
