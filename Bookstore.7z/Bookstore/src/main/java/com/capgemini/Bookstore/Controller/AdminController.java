package com.capgemini.Bookstore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Category;
import com.capgemini.Bookstore.bean.Customer;
import com.capgemini.Bookstore.service.AdminService;
import com.capgemini.Bookstore.service.LoginService;

@RestController
public class AdminController {
	@Autowired
	AdminService adminservice;

	@RequestMapping(method = RequestMethod.GET, value = "/viewallcustomer")
	public List<Customer> viewAllCustomer() {
		System.out.println("Hello:::::");
		return adminservice.viewAllCustomer();	
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/updateadmin/{adminEmailId}")
	public Admin updateAdmin(@PathVariable("adminEmailId")String email, @RequestBody Admin admin) {
		System.out.println("Hello:::::"+email+"::"+admin);
		return adminservice.updateAdmin(email,admin);	
	}
	@RequestMapping(method = RequestMethod.DELETE, value = "/admindelete/{adminId}")
	public Admin deleteAdmin(@PathVariable("adminId")int id) {
		System.out.println("adminId"+id);
		return adminservice.deleteAdmin(id);
		
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/createcategory")
	public void createCategory(@RequestBody Category category) {
		 adminservice.createCategory(category);
	}
	@RequestMapping(method = RequestMethod.GET, value = "/viewallcategory")
	public List<Category> viewAllCategories(){
		return adminservice.viewAllCategories();
		
	}
	@RequestMapping(method = RequestMethod.GET, value = "/updatecategory/{categoryId}")
	public Category updateCategories(@PathVariable("categoryId") int categoryId,@RequestBody Category category){
		return adminservice.updateCategories(categoryId,category);
		
		
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/categorydelete/{categoryId}")
	public List<Category> deleteCategories(@PathVariable("categoryId")int id){
		return adminservice.deleteCategories(id);
		
		
		
		
	}
	
	
}
