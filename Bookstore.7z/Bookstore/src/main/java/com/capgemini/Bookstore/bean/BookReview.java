package com.capgemini.Bookstore.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "bookreview")

public class BookReview {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="review_ID")
	private int reviewId;
	
//	@Column(name="book_ID")
	@OneToOne
	private Book bookId;
	
//	@Column(name="cust_ID")
	@OneToOne
	private Customer customerId;
//	@Column(name="review_detail")
	@OneToOne
	private BookReviewDetail bookReviewDetailID;
	public BookReview(int reviewId, Book bookId, Customer customerId, BookReviewDetail bookReviewDetailID) {
		super();
		this.reviewId = reviewId;
		this.bookId = bookId;
		this.customerId = customerId;
		this.bookReviewDetailID = bookReviewDetailID;
	}
	public BookReview() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public Book getBookId() {
		return bookId;
	}
	public void setBookId(Book bookId) {
		this.bookId = bookId;
	}
	public Customer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}
	public BookReviewDetail getBookReviewDetailID() {
		return bookReviewDetailID;
	}
	public void setBookReviewDetailID(BookReviewDetail bookReviewDetailID) {
		this.bookReviewDetailID = bookReviewDetailID;
	}
	@Override
	public String toString() {
		return "BookReview [reviewId=" + reviewId + ", bookId=" + bookId + ", customerId=" + customerId
				+ ", bookReviewDetailID=" + bookReviewDetailID + "]";
	}
	
	

}
