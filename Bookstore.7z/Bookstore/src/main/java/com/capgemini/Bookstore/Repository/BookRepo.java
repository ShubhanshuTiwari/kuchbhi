package com.capgemini.Bookstore.Repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;
@Repository
public interface BookRepo {
	
	public List<Book> specificCategory();
	public List<Book> mostRecentPublishedBook();
	public List<Book> viewBestSellingBook();
	public List<Book> mostFavouredBook();
	public List<BookReview> viewAllCustomerReview();
	

}
