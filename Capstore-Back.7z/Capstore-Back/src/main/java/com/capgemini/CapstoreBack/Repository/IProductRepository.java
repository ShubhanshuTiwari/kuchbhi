package com.capgemini.CapstoreBack.Repository;

import java.util.List;

import com.capgemini.CapstoreBack.bean.Product;

public interface IProductRepository {

	
	public List<Product> getProduct();
	public List<Product> sortPriceLowToHigh();
	public List<Product> sortPriceHighToLow();
	public List<Product> getSearch(String search);	
	public List<Product> single(int idd);
}
