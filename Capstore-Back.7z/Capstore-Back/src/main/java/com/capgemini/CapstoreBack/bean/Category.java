package com.capgemini.CapstoreBack.bean;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
