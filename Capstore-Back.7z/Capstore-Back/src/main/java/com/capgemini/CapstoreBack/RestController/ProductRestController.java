package com.capgemini.CapstoreBack.RestController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.capgemini.CapstoreBack.bean.Product;
import com.capgemini.CapstoreBack.service.IProductService;

@RestController
public class ProductRestController {

	@Autowired
	IProductService productService;
	
	@RequestMapping(value="/capstore")
	public List<Product> getProduct(){
		System.out.println("hi in capstore");
		System.out.println(productService.getProduct());
		return productService.getProduct();
	}
	@RequestMapping("/findbylowtohigh")
	public List<Product> sortbylowtohigh( ModelMap map) {
		System.out.println("hi in low to high");
		System.out.println(productService.sortPriceLowToHigh());
		 return productService.sortPriceLowToHigh();
	}
	
	@RequestMapping("/findbyhightoLow")
	public List<Product> sortbyhightolow( ModelMap map) {
		System.out.println("hi in high to low");
		System.out.println(productService.sortPriceHighToLow());
		 return productService.sortPriceHighToLow();
	}
	@RequestMapping("/search/{search}")
	public List<Product> search( String search) {
		System.out.println("hi in search");
		System.out.println(productService.getSearch(search));
		 return productService.getSearch(search);
	}
	
	@RequestMapping("/single/{id}")
	public List<Product> single(@PathVariable(value="id") String id) {
		int idd=Integer.parseInt(id);
		System.out.println("hi in single");
		System.out.println(productService.single(idd));
		 return productService.single(idd);
	}
	
	
}
