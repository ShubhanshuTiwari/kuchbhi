package com.capgemini.CapstoreBack.service;

import java.util.List;

import com.capgemini.CapstoreBack.bean.Product;



public interface IProductService {

	public List<Product> getProduct();
	public List<Product> sortPriceLowToHigh();
	public List<Product> sortPriceHighToLow();
	public List<Product> getSearch(String search);
	public List<Product> single(int idd);
}
